This Oauth 2 application is designed to protect the Greeting Service by acess token.
Used in memory H2 database from spring micro services framework to store the user credentials.
CommandLineRunner in the configuration class LoadUserAccounts loads the user account details in to in memory H2 database as soon as the application is booted.


Instructions to load and run the application

1) Upload the project in to Intellij IDE
2) File -> New -> Projects from existing sources ,select the path to this project' sbuild.gradle file.
3) Run the application OauthSecurityApplication to load configure the clients iphone and android clients that will access the protected resource greeing service given the access token.

Go to postman to get the access token required to access the greeting service.

1) Put the URL as shown in the attached screen shot (Getting Access Token from Postman1) by providing the username and password (padma,padma or edureka, edureka) 
and the grant type to password in the body of the request.

2) Go to Authorization tab and select the Basic Auth from the drop down, and put the client details to iphone and password or secret code to edureka on the right 
as shown in the attached screenshot (Getting Access Token from Postman2) and hit Send.

3) Take the access token granted for iphone client as shown in the attached screenshot Getting Access Token from Postman3 and follow the step 4.

4) Provide access token as shown in the attached screenshot (Access the Greeting Resource Using The Access Token from Postman1)


