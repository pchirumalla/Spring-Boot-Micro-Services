package com.edureka.oauthsecurity;

import com.edureka.oauthsecurity.model.UserAccount;
import com.edureka.oauthsecurity.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.stream.Stream;

/**
 * Spring security module saving the user to in memory DB
 */
@Configuration
public class LoadUserAccounts {
    public static void main(String[] args) {
        SpringApplication.run(LoadUserAccounts.class, args);
    }
    //This is to save the user details in to in memory database as soon as the application starts.
    @Bean
    public CommandLineRunner commandLineRunner(UserRepository userRepository){
        return args-> Stream.of("edureka,{noop}edureka","padma,{noop}padma")
                .map(u->u.split(","))
                .forEach(t->userRepository.save(new UserAccount(t[0],t[1],true)));
    }

}




