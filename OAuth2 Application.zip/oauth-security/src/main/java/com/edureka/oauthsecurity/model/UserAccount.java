package com.edureka.oauthsecurity.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Entity
@NoArgsConstructor
public class UserAccount {
    @Id
    @GeneratedValue
    private Long id;

    public UserAccount(String username, String password, boolean active) {
        this.userName = username;
        this.password = password;
        this.active = active;
    }

    private String userName;
    private String password;
    private boolean active;


}
