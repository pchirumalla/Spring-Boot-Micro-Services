package com.edureka.oauthsecurity.repository;

import com.edureka.oauthsecurity.model.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public interface UserRepository extends JpaRepository<UserAccount, Long> {
      public Optional<UserAccount> findByUserName(String userName);
}