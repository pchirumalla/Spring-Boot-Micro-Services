package com.edureka.oauthsecurity.resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
public class GreetingResource {
   // @PreAuthorize("hasRole('ADMIN')")
   // @RolesAllowed("ADMIN")
    @GetMapping("/user")
    public Principal user(Principal user){
        return user;
    }
    @GetMapping("greet")
    public String sayHello(){
        return "Happy New Year";
    }
    /**
     * {
     *     "access_token": "7467372c-7339-4170-a92f-8aee6c96cace",
     *     "token_type": "bearer",
     *     "refresh_token": "7f3560b4-9964-47a3-bba8-9c6e3e83c56d",
     *     "expires_in": 43199,
     *     "scope": "read write"
     * }
     */
}
