This is a shopping cart application created with spring boot 2.0.4 micro services framework.
Download and run the application from STS or Intellij or Eclipse.
You might have to adjust the lombok annotation settings in the IDE.
Please refer to the screenshots attached and welcome to contribute to the application.
My goal is to make it full fledged shopping cart app and host it on AWS.
