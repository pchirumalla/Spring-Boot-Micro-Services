Run all four services in the below order
1)Discovery-service
2)Product-service
3)Order-service
4)Recommendation-service

To browse the product by text
http://localhost:8081/product/byName/containing?name=Flat
http://localhost:8081/product/byName/containing?name=CURL


To add the product to the order
