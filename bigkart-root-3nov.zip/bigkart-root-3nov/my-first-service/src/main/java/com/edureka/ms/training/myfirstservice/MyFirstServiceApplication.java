package com.edureka.ms.training.myfirstservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class MyFirstServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyFirstServiceApplication.class, args);
    }
}
