package com.edureka.ms.training.order.service.tdd.orderservicetdd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderServiceTddApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderServiceTddApplication.class, args);
    }
}
