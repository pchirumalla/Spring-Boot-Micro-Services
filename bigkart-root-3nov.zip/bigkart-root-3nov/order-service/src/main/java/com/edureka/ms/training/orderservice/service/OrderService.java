package com.edureka.ms.training.orderservice.service;

import com.edureka.ms.training.orderservice.client.ProductClient;
import com.edureka.ms.training.orderservice.model.Order;
import com.edureka.ms.training.orderservice.model.model.OrderRequest;
import com.edureka.ms.training.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class OrderService {
    @Autowired
    OrderRepository orderRepository;

    @Autowired
    RestTemplate restTemplate;

    //@Autowired
    ProductClient productClient;

    @Retryable(value = {ProductServiceNotReachableException.class}, maxAttempts = 2, backoff = @Backoff(delay=2000))
    public boolean createOrder(OrderRequest orderRequest) {
        Order orderToBeSaved = OrderTransformer.transform(orderRequest);
        ResponseEntity<Boolean> forEntity = null;
        try {
            forEntity = restTemplate.getForEntity("http://product-service/product?id" + orderRequest.getProductDetail().getCode(), Boolean.class);
        }catch (Exception e){

            throw new ProductServiceNotReachableException();
        }
        Order saved = null;
        if(forEntity.getBody()){
            saved = orderRepository.save(orderToBeSaved);
        }
        //TODO - Contact Product service to see if the product exists.
        return saved != null;
    }
    public static class ProductServiceNotReachableException extends  RuntimeException{};

    public boolean createOrderWithFeign(OrderRequest orderRequest) {
        Order orderToBeSaved = OrderTransformer.transform(orderRequest);
        ResponseEntity<Boolean> forEntity = productClient.isProductInventory(orderRequest.getProductDetail().getCode());
        Order saved = null;
        if(forEntity.getBody()){
            saved = orderRepository.save(orderToBeSaved);
        }
        //TODO - Contact Product service to see if the product exists.
        return saved != null;
    }
    private static class OrderTransformer {
        public static Order transform(OrderRequest orderRequest) {
            return Order.builder().id(orderRequest.getId())
                    .userId(orderRequest.getUserId())
                    .quantity(orderRequest.getQuantity())
                    .address(orderRequest.getAddress())
                    .productDetail(Order.ProductDetail.builder()
                            .code(orderRequest.getProductDetail().getCode())
                            .description(orderRequest.getProductDetail().getDescription())
                            .name(orderRequest.getProductDetail().getName()).build()).build();
        }
    }
}