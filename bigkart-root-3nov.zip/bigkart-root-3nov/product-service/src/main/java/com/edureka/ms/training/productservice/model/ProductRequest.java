package com.edureka.ms.training.productservice.model;

import lombok.*;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ProductRequest {
    Integer id;

    String name;

    String description;
}
