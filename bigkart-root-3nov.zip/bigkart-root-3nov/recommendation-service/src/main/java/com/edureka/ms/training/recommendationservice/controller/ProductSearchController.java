package com.edureka.ms.training.recommendationservice.controller;

import java.util.stream.Stream;

import org.elasticsearch.search.SearchService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edureka.ms.training.recommendationservice.model.Product;
import com.edureka.ms.training.recommendationservice.service.RecommendationService;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@RequestMapping("/search")
public class ProductSearchController {
	RecommendationService recommendationService;
	
	@GetMapping("/name/{name}")
	public Stream<Product> searchByName(@PathVariable String name){
		return recommendationService.searchByName(name);
	}
	
	@GetMapping("/{text}")
	public Stream<Product> searchEverything(@PathVariable String text){
		return recommendationService.search(text);
	}
	
	

}
