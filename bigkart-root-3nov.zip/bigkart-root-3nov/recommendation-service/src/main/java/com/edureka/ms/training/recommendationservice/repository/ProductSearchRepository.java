package com.edureka.ms.training.recommendationservice.repository;

import java.util.stream.Stream;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import com.edureka.ms.training.recommendationservice.model.Product;

@Repository
public interface ProductSearchRepository extends ElasticsearchRepository<Product, Integer> {
	Stream<Product> findByNameIgnoringCase(String name);
	
}
