package com.edureka.ms.training.recommendationservice.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Stream;

import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.stereotype.Service;

import com.edureka.ms.training.recommendationservice.model.Product;
import com.edureka.ms.training.recommendationservice.repository.ProductSearchRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
@EnableBinding(Sink.class)
public class RecommendationService {
	
	ProductSearchRepository productSearchRepository;
	
	ElasticsearchTemplate elasticsearchTemplate;
	
    public List<Product> searchByName(String name){
    	return productSearchRepository.findByNameIgnoringCase(name);
    }
    
    public Stream<Product> search(String text){
    	NativeSearchQuery nativeSearchQuery = new NativeSearchQueryBuilder()
    	.withFilter(QueryBuilders.regexpQuery("_all", "*" + text + ".*" ))
    	.build();
    	return elasticsearchTemplate.queryForList(nativeSearchQuery, Product.class).stream();
	}
    
    @StreamListener(Sink.INPUT)
    public void saveProductInfo(String productInfo) {
    	String[] productData = productInfo.split(":");
    	Product product = new Product(7, productData[1], productData[2], BigDecimal.valueOf(8.99));
    	productSearchRepository.save(product);
    	System.out.println("Product "+productData[1] + "is saved");
    	
    }
}
