package org.apache.logging.log4j.core.config;

import org.apache.logging.log4j.Level;

public final class Configurator {

    private Configurator() {
    }

    public static void setLevel(final String name, final Level level) {
    }

}