package org.apache.logging.log4j.core.config;

public class LoggerConfig {

}
