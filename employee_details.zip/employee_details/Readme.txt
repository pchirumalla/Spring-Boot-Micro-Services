Load the applicaion and run the test EmployeeControllerTest. This test class has two methods, one to get the default Employee with id 1 and other one creates an employeewith given id and return it.
I am using json mapper to compare the instance retured by controller.

I didn't inject any service in to controller since i am mocking the data. 


http://localhost:8080/employee?id=1 - from postman

