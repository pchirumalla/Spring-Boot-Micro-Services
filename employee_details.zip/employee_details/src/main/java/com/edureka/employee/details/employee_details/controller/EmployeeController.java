package com.edureka.employee.details.employee_details.controller;

import com.edureka.employee.details.employee_details.model.Employee;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "employee")
public class EmployeeController {

    @GetMapping("/")
    public Employee getEmployee(){
         return Employee.builder().id(1)
                 .name("one")
                 .designation("sw engineer")
                 .salary("100000").build();
    }
    @GetMapping
    public Employee getEmployee(@RequestParam("id") Integer id) {
        return Employee.builder().id(id)
                .name("one")
                .designation("sw engineer")
                .salary("100000").build();
    }


}