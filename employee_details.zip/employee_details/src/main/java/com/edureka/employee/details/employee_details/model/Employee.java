package com.edureka.employee.details.employee_details.model;

import lombok.*;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class Employee {

    private Integer id;

    private String name;

    private String designation;

    private String salary;

    public Integer getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getDesignation() {
        return designation;
    }
    public String getSalary() {
        return salary;
    }
    /*public void setId(Integer id) {
        this.id = id;
    }



    public void setName(String name) {
        this.name = name;
    }



    public void setDesignation(String designation) {
        this.designation = designation;
    }



    public void setSalary(String salary) {
        this.salary = salary;
    }

   public Employee(Integer id, String name, String designation, String salary){
        this.id= id;
        this.name=name;
        this.designation =designation;
        this.salary = salary;
    }*/
}
