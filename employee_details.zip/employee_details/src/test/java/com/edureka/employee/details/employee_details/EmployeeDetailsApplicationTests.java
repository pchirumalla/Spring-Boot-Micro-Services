package com.edureka.employee.details.employee_details;

import com.edureka.employee.details.employee_details.model.Employee;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmployeeDetailsApplicationTests {

    @Test
    public void contextLoads() {
    }

    @Test
    public void testBuildEmployeeDetails(){
       Employee employee= Employee.builder().id(1)
                .name("one")
                .designation("sw engineer")
                .salary("100000").build();

        Assert.assertEquals(employee.getId().intValue(), 1);
        Assert.assertEquals(employee.getName(), "one");
        Assert.assertEquals(employee.getDesignation(), "sw engineer");
        Assert.assertEquals(employee.getSalary(), "100000");
 }



}
